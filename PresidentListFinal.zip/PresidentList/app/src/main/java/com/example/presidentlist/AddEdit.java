package com.example.presidentlist;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AddEdit extends AppCompatActivity {

    Button ok_btn,cancel_btn,dlt_btn;
    EditText nameet,dateet,imageet;
    TextView idtv;
    List<President> presidents;
    int id;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private PresidentDao presidentDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit);
        ok_btn=findViewById(R.id.ok_btn);
        cancel_btn=findViewById(R.id.cancel_btn);
        dlt_btn=findViewById(R.id.dltbutton);
        nameet=findViewById(R.id.editName);
        dateet=findViewById(R.id.editDate);
        imageet=findViewById(R.id.editImage);
        idtv=findViewById(R.id.idtv);

        presidentDao= InitDB.appDatabase.presidentDao();
        Intent i=getIntent();
        id=i.getIntExtra("id",-1);

        if(id>=0)
        {
            dlt_btn.setVisibility(View.VISIBLE);
        }
        else{
            dlt_btn.setVisibility(View.INVISIBLE);
        }

        // Edit mode
        executor.execute(new Runnable() {
                 @Override
                 public void run() {
                     if (id >= 0) {
                         President p = presidentDao.getPresidentByID(id);
                         nameet.setText(p.getName());
                         dateet.setText(p.getDateOfElection());
                         imageet.setText(p.getImageUrl());
                         idtv.setText(String.valueOf(id));
                     }
                 }
        });

        ok_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                executor.execute(new Runnable() {
                    @Override
                    public void run() {
                        // This is the background thread (replaces doInBackground)
                        if(id>=0)
                        {
                            President up=presidentDao.getPresidentByID(id);
                            up.setName(nameet.getText().toString());
                            up.setDateOfElection(dateet.getText().toString());
                            up.setImageUrl(imageet.getText().toString());
                            presidentDao.update(up);
                        }

                        // create new president
                        else {
                            President newp=new President(nameet.getText().toString(),dateet.getText().toString(),imageet.getText().toString());
                            presidentDao.insert(newp);
                        }

                    }
                });

                Intent i=new Intent(AddEdit.this,MainActivity.class);
                startActivity(i);
            }
        });

        cancel_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(AddEdit.this,MainActivity.class);
                startActivity(i);
            }
        });

        dlt_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                executor.execute(new Runnable() {
                    @Override
                    public void run() {
                        // This is the background thread (replaces doInBackground)
                        if(id>=0)
                        {
                            President dlt=presidentDao.getPresidentByID(id);
                            presidentDao.delete(dlt);
                        }


                    }
                });

                Intent i=new Intent(AddEdit.this,MainActivity.class);
                startActivity(i);
            }
        });


    }
}