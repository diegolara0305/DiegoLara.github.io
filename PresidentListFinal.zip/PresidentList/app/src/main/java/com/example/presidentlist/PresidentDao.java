package com.example.presidentlist;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface PresidentDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    public void insert(President president);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    public void insertAll(President... presidents);

    @Update
    public void update(President president);

    @Delete
    public void delete(President president);

    @Query("SELECT * FROM president_table WHERE id= :president_id")
    President getPresidentByID(int president_id);

    @Query("SELECT * FROM president_table")
    List<President> getAllPresidents();
}
