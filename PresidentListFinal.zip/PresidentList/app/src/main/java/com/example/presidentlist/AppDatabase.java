package com.example.presidentlist;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;


@Database(entities = {President.class}, version = 1,exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {
    public abstract PresidentDao presidentDao();

    private static volatile AppDatabase DBINSTANCE;

    public static AppDatabase getDatabase(final Context context)
    {
        if(DBINSTANCE==null)
        {
            synchronized(AppDatabase.class) {
                if(DBINSTANCE==null){
                    DBINSTANCE= Room.databaseBuilder(context.getApplicationContext()
                            ,AppDatabase.class,"PresidentAppDatabase5").build();
                }
            }
        }
        return DBINSTANCE;
    }


}
