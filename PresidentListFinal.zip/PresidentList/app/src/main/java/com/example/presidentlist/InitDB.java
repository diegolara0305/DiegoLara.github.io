package com.example.presidentlist;
import android.app.Application;

public class InitDB extends Application {

    public static AppDatabase appDatabase;


    @Override
    public void onCreate() {
        super.onCreate();
        appDatabase=AppDatabase.getDatabase(this);
    }

}
