package com.example.presidentlist;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.MyViewHolder> {

    List<President> presidents;
    Context context;
    public RecyclerViewAdapter(List<President> presidents, Context context) {
        this.presidents = presidents;
        this.context = context;
    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view
                = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.president_item,
                        parent, false);
        MyViewHolder viewHolder=new MyViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.president_name.setText(presidents.get(position).getName());
        holder.prsident_time.setText(presidents.get(position).getDateOfElection());
        Glide.with(this.context).load(presidents.get(position).getImageUrl()).into(holder.president_image);
        holder.layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(context,AddEdit.class);
                i.putExtra("id",presidents.get(position).getId());
                context.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return presidents.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder
    {
        ImageView president_image;
        TextView president_name;
        TextView prsident_time;
        ConstraintLayout layout;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            president_image=itemView.findViewById(R.id.president_iv);
            president_name=itemView.findViewById(R.id.president_name_tv);
            prsident_time=itemView.findViewById(R.id.President_time_tv);
            layout=itemView.findViewById(R.id.president_item_layout);
        }
    }
    public void updateData(List<President> newData) {
        this.presidents = newData;
        notifyDataSetChanged();  // Notify the adapter that the data has changed
    }

}
