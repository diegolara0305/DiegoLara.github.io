package com.example.presidentlist;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.util.Comparator;

@Entity(tableName = "president_table")
public class President {
    @PrimaryKey(autoGenerate = true)
    private int id;

    @ColumnInfo
    private String name;

    @ColumnInfo
    private String dateOfElection;

    @ColumnInfo
    private String imageUrl;

    public President( String name, String dateOfElection, String imageUrl) {
        this.name = name;
        this.dateOfElection = dateOfElection;
        this.imageUrl = imageUrl;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDateOfElection() {
        return dateOfElection;
    }

    public void setDateOfElection(String dateOfElection) {
        this.dateOfElection = dateOfElection;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public static Comparator<President> nameatozcomp=new Comparator<President>() {
        @Override
        public int compare(President p1, President p2) {
            return p1.getName().compareTo(p2.getName());
        }
    };

    public static Comparator<President> nameztoacomp=new Comparator<President>() {
        @Override
        public int compare(President p1, President p2) {
            return p2.getName().compareTo(p1.getName());
        }
    };

    public static Comparator<President> dateasccomp=new Comparator<President>() {
        @Override
        public int compare(President p1, President p2) {
            return Integer.parseInt(p1.getDateOfElection())-Integer.parseInt(p2.getDateOfElection());
        }
    };

    public static Comparator<President> datedesccomp=new Comparator<President>() {
        @Override
        public int compare(President p1, President p2) {
            return Integer.parseInt(p2.getDateOfElection())-Integer.parseInt(p1.getDateOfElection());
        }
    };

    @Override
    public String toString() {
        return "President{"  +
                ", ID='" + id + '\'' +
                ", name='" + name + '\'' +
                ", dateOfElection='" + dateOfElection + '\'' +
                ", imageUrl='" + imageUrl + '\'' +
                '}';
    }




}
