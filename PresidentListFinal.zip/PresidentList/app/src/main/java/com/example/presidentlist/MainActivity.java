package com.example.presidentlist;

import static android.app.ProgressDialog.show;
import static android.widget.Toast.makeText;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    Button add_btn;

    List<President> presidents=new ArrayList<>();

    Menu menu;

    private RecyclerView recyclerView;
    private RecyclerView.Adapter ad;
    private RecyclerView.LayoutManager layoutmanager;

    private  PresidentDao presidentDao;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView=findViewById(R.id.rv_presidentList);
        recyclerView.setHasFixedSize(true);
        layoutmanager=new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutmanager);
        ad=new RecyclerViewAdapter(presidents,MainActivity.this);
        recyclerView.setAdapter(ad);

        presidentDao= InitDB.appDatabase.presidentDao();

        // Execute the database query on a background thread
        executor.execute(new Runnable() {
            @Override
            public void run() {
                // This is the background thread (replaces doInBackground)
                presidents = presidentDao.getAllPresidents();

                // Switch to the main thread to update the UI
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        // This is the main thread (replaces onPostExecute)
                        if (ad instanceof RecyclerViewAdapter) {
                            ((RecyclerViewAdapter) ad).updateData(presidents);
                        }
                        ad.notifyDataSetChanged();
                    }
                });
            }
        });


        // add Button Functionality
        add_btn=findViewById(R.id.add_btn);
        add_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(MainActivity.this,AddEdit.class);
                startActivity(i);
            }
        });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.sort_menu,menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id=item.getItemId();
        if(id==R.id.menu_atoz) {
            Collections.sort(presidents,President.nameatozcomp);
            ad.notifyDataSetChanged();
            Toast.makeText(MainActivity.this,"Selected A to Z",Toast.LENGTH_LONG).show();
            return true;
        }
        else if(id==R.id.menu_ztoa){
            Collections.sort(presidents,President.nameztoacomp);
            ad.notifyDataSetChanged();
            Toast.makeText(MainActivity.this,"Selected Z to A",Toast.LENGTH_LONG).show();
            return true;
        } else if (id==R.id.menu_asc) {
            Collections.sort(presidents,President.dateasccomp);
            ad.notifyDataSetChanged();
            Toast.makeText(MainActivity.this,"Selected Ascending order",Toast.LENGTH_LONG).show();
            return true;
        }
        else if(id==R.id.menu_desc){
            Collections.sort(presidents,President.datedesccomp);
            ad.notifyDataSetChanged();
            Toast.makeText(MainActivity.this,"Selected Descending order",Toast.LENGTH_LONG).show();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}